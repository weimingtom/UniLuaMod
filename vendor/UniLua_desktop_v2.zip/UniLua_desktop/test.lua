﻿
local libfoo = require "libfoo.cs"

print(libfoo.add(42, 1))
print(libfoo.sub(42, 22))