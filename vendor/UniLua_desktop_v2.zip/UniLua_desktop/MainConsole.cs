﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UniLua;

namespace UniLua_desktop
{
    public class MainConsole
    {
        public static void Main(String[] args)
        {
            Console.WriteLine("here");

            //Test();
            LuaScriptController t = new LuaScriptController();
            t.LuaScriptFile = "framework/test.lua";
            t.Awake();
            t.Start();

            Console.ReadLine();
        }
    }
}
