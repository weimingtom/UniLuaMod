﻿using System;

namespace UniLua.Tools
{
	// thanks to dharco
	// refer to https://github.com/dharco/UniLua/commit/2854ddf2500ab2f943f01a6d3c9af767c092ce75
	public class ULDebug
	{
		public static System.Action<object> Log = NoAction;
		public static System.Action<object> LogError = NoAction;

		private static void NoAction(object msg) { }
		private static void LogConsoleAction(object msg)
		{
			Console.WriteLine(msg.ToString());
		}
		
		static ULDebug()
		{

			//Log = Logger.Log;
			//LogError = Logger.LogError;
			if (false)
			{
				Log = NoAction;
            	LogError = NoAction;
			}
			else
			{
            	Log = LogConsoleAction;
            	LogError = LogConsoleAction;
			}
        }
	}
}

