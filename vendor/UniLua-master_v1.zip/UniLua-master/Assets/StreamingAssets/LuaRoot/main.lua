
print("main.lua")

-- local Foobar = require("foobar")
-- 
-- require("test.test")
-- 
-- print(Foobar)
-- Foobar.foobar(1, "a")


